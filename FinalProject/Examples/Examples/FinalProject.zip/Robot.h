#include<stdio.h>
#include<bcm2835.h>
#include"MotorHat.h"

#ifndef ROBOT
#define ROBOT


#endif

