#ifndef MyLib_H_
#define MyLib_H_

int readButtonPress(int pin);

#endif 
